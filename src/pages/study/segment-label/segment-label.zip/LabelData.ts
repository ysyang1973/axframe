import React, { useRef, useState } from 'react';
interface ILabel {
    id: number;
    name: string;
    description: string;
}
export const [labels, setlabels] = useState([
    {
        id: 0, // Used in JSX as a key
        name: '견적요청',
        description: '견적요청 리스트(사용자 지정)',
    }, {
        id: 1, // Used in JSX as a key
        name: '미구매',
        description: '견적 받은 후 구매 안한 리스트',
    }, {
        id: 2, // Used in JSX as a key
        name: '연락보류',
        description: '직접 전화 주기로 한 업체',
    }, {
        id: 3, // Used in JSX as a key
        name: '입금대기',
        description: '입금 전 업체',
    }, {
        id: 4, // Used in JSX as a key
        name: 'Audit',
        description: '감사 건으로 안내받은 리스트',
    }, {
        id: 5, // Used in JSX as a key
        name: '요청사항',
        description: '요구사항 있는 업체',
    },
]);


