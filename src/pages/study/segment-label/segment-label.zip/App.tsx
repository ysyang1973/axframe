import styled from "@emotion/styled";
import { Button, Form, Divider } from "antd";
import { ProgramTitle } from "@core/components/common";
import React from "react";
import { AXFIRevert, AXFIWriteForm } from "@axframe/icon";
import { PageLayout } from "styles/pageStyled";
import { useI18n } from "@core/hooks/useI18n";
import { errorHandling } from "utils/errorHandling";
import Labels from './Labels';
interface Props { }

function App({ }: Props) {
  const handleSearch = React.useCallback(async () => {
    try {
    } catch (e) {
      await errorHandling(e);
    }
  }, []);

  const onRemove = id => {
    // user.id 가 파라미터로 일치하지 않는 원소만 추출해서 새로운 배열을 만듬
    // = user.id 가 id 인 것을 제거함
    // setUsers(users.filter(user => user.id !== id));
  };

  const { t } = useI18n();
  return (
    <Container stretch role={"page-container"}>
      <Header>
        <ProgramTitle>
          <Button icon={<AXFIWriteForm />} size='small' type={"text"}>
            {t.button.reset}
          </Button>
        </ProgramTitle>
        <ButtonGroup compact>
          <Button onClick={handleSearch}>{t.button.search}</Button>
          <Button>{t.button.addNew}</Button>
        </ButtonGroup>
      </Header>
      <Body>
        <Labels />
      </Body>
    </Container>
  );
}

const Container = styled(PageLayout)``;
const Header = styled(PageLayout.Header)``;
const ButtonGroup = styled(PageLayout.ButtonGroup)``;
const Body = styled(PageLayout.Body)``;

export default App;
